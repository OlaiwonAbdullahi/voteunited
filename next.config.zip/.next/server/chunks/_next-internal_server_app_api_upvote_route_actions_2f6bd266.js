module.exports=[15404,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_upvote_route_actions_2f6bd266.js.map