module.exports=[50018,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bills_page_actions_2f52431b.js.map