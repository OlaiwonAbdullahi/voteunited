module.exports=[34522,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_vote_page_actions_aee3d87a.js.map