module.exports=[66128,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_resources_%5Bid%5D_page_actions_b9f76e14.js.map