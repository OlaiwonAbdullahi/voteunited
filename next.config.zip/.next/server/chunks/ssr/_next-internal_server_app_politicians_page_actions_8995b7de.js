module.exports=[31670,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_politicians_page_actions_8995b7de.js.map