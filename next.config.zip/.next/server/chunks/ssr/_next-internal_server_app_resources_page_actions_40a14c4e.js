module.exports=[50469,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_resources_page_actions_40a14c4e.js.map