(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9316546f._.css",
  "static/chunks/node_modules_a5e20115._.js",
  "static/chunks/_99a391e0._.js"
],
    source: "dynamic"
});
