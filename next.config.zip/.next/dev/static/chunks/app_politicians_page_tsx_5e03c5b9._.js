(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_adfc5750._.js",
  "static/chunks/_d2e5f028._.js"
],
    source: "dynamic"
});
