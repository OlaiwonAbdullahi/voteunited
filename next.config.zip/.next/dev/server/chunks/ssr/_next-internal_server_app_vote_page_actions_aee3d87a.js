module.exports = [
"[project]/.next-internal/server/app/vote/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_vote_page_actions_aee3d87a.js.map