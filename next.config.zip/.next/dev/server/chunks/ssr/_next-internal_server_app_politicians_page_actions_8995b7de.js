module.exports = [
"[project]/.next-internal/server/app/politicians/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_politicians_page_actions_8995b7de.js.map