module.exports = [
"[project]/.next-internal/server/app/resources/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_resources_page_actions_40a14c4e.js.map